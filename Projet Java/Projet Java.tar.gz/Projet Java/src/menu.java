public class menu {
      int x;
      int y;
      public menu(ecran vitrine) {
        this.x = vitrine.x;
        this.y = vitrine.y;

      }

  public  void aff_menu(String touche,menu carnaval) {
    /*
    System.out.print("+");
    for (int i = 0;i < carnaval.x; i++ ) {
      System.out.print("-");
    }
    System.out.println("+");
    for (int j = 0;j < carnaval.y ;j++ ) {
      System.out.print("|");
      for (int k = 0;k < carnaval.x ;k++ ) {            // CA FAIT UN PETIT CADRE AVEC RIEN DEDANT 
        System.out.print(" ");
      }
      System.out.println("|");
    }
    System.out.print("+");
    for (int x = 0; x < carnaval.x ;x ++ ) {
      System.out.print("-");
    }
    System.out.println("+");

    */
    for (int i = 0;i < carnaval.x; i++ ) {
      System.out.print("-");
    }
    System.out.println("");
    for (int x = 0;x<carnaval.x ;x++ ) {
      for (int j = 0 ;j<carnaval.y /4 ;j++ ) {
          System.out.print(" ");
      }
    }
      for (int m = 0;m < carnaval.x/3 ;m ++ ) {
        System.out.print(" ");
      }
      System.out.print("1.CHOISIR LES NIVEAUX");
      System.out.println("");
      for (int x = 0;x<carnaval.x ;x++ ) {
        for (int j = 0 ;j<carnaval.y /4 ;j++ ) {
            System.out.print(" ");
        }
      }
      for (int m = 0;m < carnaval.x/3 ;m ++ ) {
        System.out.print(" ");

      }
      System.out.print("2.SAISIR LES PARAM POUR JOUER ");
      System.out.println();

      for (int x = 0;x<carnaval.x ;x++ ) {
        for (int j = 0 ;j<carnaval.y /4 ;j++ ) {
            System.out.print(" ");
        }
      }
      System.out.println();



    for (int i = 0;i < carnaval.x; i++ ) {
      System.out.print("-");
    }
      System.out.println("");

  //
  }
}
