import java.util.Scanner;
public class gamer {

    int x;
    int y;

    public gamer()
    {
      this.x = 10;
      this.y = 10;
    }

    public void deplacer(String touche, ecran selfie)
    {

      if (touche.equals("z")) {  // en haut
        if (this.y > 0) {
          this.y -= 1;

        }
      }
      else if (touche.equals("s")) {  // en bas
        if (this.y < selfie.y-1) {
          this.y += 1;
        }
      }
      else if (touche.equals("q")) { // a gauche
        if (this.x > 0 ) {
        this.x -= 1;
      }
      }
      else if (touche.equals("d")) { // a droite
        if (this.x < selfie.x -1) {
          this.x += 1;
        }
      }


    }





}
