public class ecran{
      int x;
      int y;

      public ecran(int longueur, int hauteur){
        this.x = longueur;
        this.y = hauteur;
      }
      public ecran()
      {
        this.x = 30;
        this.y = 20;

      }
      public static void clearScreen() {
        System.out.print("\033[H\033[2J");
        System.out.flush();
      }

      public void affiche_game (gamer j1, monster m1){
        int i = 0,j = 0;
        int cmpt  = 0,cmpt2 = 0;
        for (i = 0;i < this.y ;i++ ) {


          for (j = 0;j < this.x * 2 ;j++ ) {
              if ((j<this.x)) {
                if (j == j1.x && i == j1.y) {
                  System.out.print("0");
                }
                else if (m1.x == j && m1.y == i) {
                  System.out.print("M");
                }
                else
                {
                  System.out.print("-");

                }
              }                         //PARTIE GAUCHE DE L'ECRAN

              if (j> (this.x)) {
                  if (i  == 2 && cmpt != 1) {                    //PARTIE DROITE DE L'ECRAN
                        System.out.print("      VIE JOUER : ");
                        cmpt = 1;
                  }
                  if (i  == 4 && cmpt2 != 1 ) {                    //PARTIE DROITE DE L'ECRAN
                        System.out.print("      ATTAQUE JOUER : ");
                        cmpt2 = 1;
                  }
              }
          }

          System.out.println();
        }
      }
    }
