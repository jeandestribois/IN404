import  java.util.Scanner;

public class main{

  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);

    gamer j1 = new gamer();
    monster m1 = new monster();
    ecran terrain = new ecran();
    menu VALD = new menu(terrain);
      String  scanString = "lolo";

      System.out.println("POUR quiter tapper la lettre p °_° ");
      System.out.println("POUR commencer tapper entree  °_° ");
      VALD.aff_menu(scanString,VALD);

    while (!scanString.equals("p"))
    {
        scanString = scan.nextLine();
        ecran.clearScreen();

        j1.deplacer(scanString,terrain);
        terrain.affiche_game(j1,m1);


    }
          ecran.clearScreen();
          System.out.println("VOUS ETES SORTI DU JEU");




  }

}
