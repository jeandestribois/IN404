import java.util.Random;
public class monster {

int x;
int y;
int attack = 10;
int health = 100;

private static int getRandomNumberInRange(int min, int max) {

	Random r = new Random();
	return r.ints(min, (max + 1)).findFirst().getAsInt();

}

public monster(int longueur, int hauteur) {
	this.x = longueur;
	this.y = hauteur;


}
public  monster()
{
	this.x = 18;
	this.y = 18;


}


}
